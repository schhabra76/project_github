const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 2000 
mongoose.connect('mongodb://localhost:27017/node-mongo-form', { useNewUrlParser: true, useUnifiedTopology: true });


const userSchema = new mongoose.Schema({
  user_name: String,
  user_age: Number,
  user_city: String,
  user_phone: String,
  user_email: String,
});


const User = mongoose.model('User', userSchema);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));


app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/form.html');
});

app.post('/submit', (req, res) => {
  const userData = {
    user_name: req.body.user_name,
    user_age: parseInt(req.body.user_age),
    user_city: req.body.user_city,
    user_phone: req.body.user_phone,
    user_email: req.body.user_email,
  };

  
  const newUser = new User(userData);

  
  newUser.save((err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error saving to database');
    } else {
      res.send('Data saved successfully');
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
